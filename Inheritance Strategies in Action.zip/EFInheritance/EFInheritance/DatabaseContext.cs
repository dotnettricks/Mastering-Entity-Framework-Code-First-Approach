﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInheritance
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("DefaultConnection")
        {

        }
        
       // public DbSet<Student> Students { get; set; }
        public DbSet<StudentLogin> StudentLogin { get; set; }
        public DbSet<StudentDetails> StudentDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //TPH
            // modelBuilder.Entity<Student>().Map<StudentDetails>(m => m.Requires("Type").HasValue("StudentDetails")).Map<StudentLogin>(m => m.Requires("Type").HasValue("StudentLogin"));

            //TPT
            //modelBuilder.Entity<Student>().ToTable("Students");
            //modelBuilder.Entity<StudentLogin>().ToTable("StudentLogin");
            //modelBuilder.Entity<StudentDetails>().ToTable("StudentDetails");

            //TPC
            modelBuilder.Entity<StudentLogin>().Map(m =>
            {
                m.MapInheritedProperties();
                m.ToTable("StudentLogin");
            });
            modelBuilder.Entity<StudentDetails>().Map(m =>
            {
                m.MapInheritedProperties();
                m.ToTable("StudentDetails");
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
