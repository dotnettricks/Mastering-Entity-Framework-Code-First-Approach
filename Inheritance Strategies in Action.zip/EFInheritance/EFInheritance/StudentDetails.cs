﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInheritance
{
    public class StudentDetails : Student
    {
        public string Address { get; set; }
        public string Mobile { get; set; }
    }
}
