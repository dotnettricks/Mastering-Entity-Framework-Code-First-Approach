namespace EFInheritance.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class tpc : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StudentDetails",
                c => new
                    {
                        StudentId = c.Int(nullable: false),
                        Address = c.String(),
                        Mobile = c.String(),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.StudentId);
            
            CreateTable(
                "dbo.StudentLogin",
                c => new
                    {
                        StudentId = c.Int(nullable: false),
                        Username = c.String(),
                        Password = c.String(),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.StudentId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.StudentLogin");
            DropTable("dbo.StudentDetails");
        }
    }
}
