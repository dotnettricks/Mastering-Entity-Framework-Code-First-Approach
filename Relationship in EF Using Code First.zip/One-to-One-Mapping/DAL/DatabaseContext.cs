﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("DefaultConnection")
        {

        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Address> Address { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //1:0 or 1:1
            modelBuilder.Entity<Employee>().HasOptional(e => e.Address).WithRequired(ad => ad.Employee);

            base.OnModelCreating(modelBuilder);
        }
    }
}
