﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Role
    {
        public int RoleId { get; set; }
        public string Name { get; set; }

        // collection navigation property
        public ICollection<User> Users { get; set; }
    }
}
