﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public decimal UnitPrice { get; set; }

        [ForeignKey("Category")] //foreign key
        public int CategoryId { get; set; }

        // reference navigation property
        public Category Category { get; set; }
    }
}
