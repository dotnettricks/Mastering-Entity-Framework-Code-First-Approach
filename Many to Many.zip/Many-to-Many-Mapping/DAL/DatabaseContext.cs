﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("DefaultConnection")
        {

        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Address> Address { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //1:0 or 1:1
            modelBuilder.Entity<Employee>().HasOptional(e => e.Address).WithRequired(ad => ad.Employee);

            //1:m
            // modelBuilder.Entity<Product>().HasRequired(p => p.Category).WithMany(c => c.Products).HasForeignKey(p => p.CategoryId);

            //m:m
            modelBuilder.Entity<User>().HasMany(u => u.Roles).WithMany(r => r.Users).Map(ur =>
            {
                ur.MapLeftKey("UserId");
                ur.MapRightKey("RoleId");
                ur.ToTable("UserRoles");
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
