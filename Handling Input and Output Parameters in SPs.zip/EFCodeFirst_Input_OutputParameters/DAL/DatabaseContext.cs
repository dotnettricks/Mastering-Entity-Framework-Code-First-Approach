﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() : base("DefaultConnection")
        {

        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }

        public Employee fn_getEmployee(int id)
        {
            return this.Database.SqlQuery<Employee>("Select * from fn_getEmployee(@EmployeeId)", new SqlParameter("EmployeeId", id)).FirstOrDefault();
        }
        public Employee usp_getEmployee(int id)
        {
            //Method#1
            // return this.Database.SqlQuery<Employee>("Exec usp_getEmployee @EmployeeId", new SqlParameter("EmployeeId", id)).FirstOrDefault();

            //Method#2
            Employee model = new Employee();
            using (var command = this.Database.Connection.CreateCommand())
            {
                command.CommandText = "usp_getEmployee";
                command.CommandType = CommandType.StoredProcedure;

                var inputParam = new SqlParameter("EmployeeId", id);
                command.Parameters.Add(inputParam);
                this.Database.Connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                        model.Name = Convert.ToString(reader["Name"]);
                        model.Address = Convert.ToString(reader["Address"]);
                        model.Contact = Convert.ToString(reader["Contact"]);
                        model.DepartmentId = Convert.ToInt32(reader["DepartmentId"]);
                    }
                }
                this.Database.Connection.Close();
            }
            return model;
        }

        public int usp_getEmployeeCount(int id)
        {
            using (var command = this.Database.Connection.CreateCommand())
            {
                command.CommandText = "usp_getEmployeeCount";
                command.CommandType = CommandType.StoredProcedure;

                var inputParam = new SqlParameter("DepartmentId", id);
                command.Parameters.Add(inputParam);

                var outputParam = new SqlParameter()
                {
                    ParameterName = "@EmployeeCount",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.Output //output
                };
                command.Parameters.Add(outputParam);

                this.Database.Connection.Open();
                command.ExecuteReader();
                this.Database.Connection.Close();
                return (int)outputParam.Value;
            }
        }
        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasKey(e => e.EmployeeId).ToTable("Employee");
            modelBuilder.Entity<Employee>().Property(e => e.Name).IsRequired().IsUnicode(false).HasMaxLength(50);
            modelBuilder.Entity<Employee>().Property(e => e.Address).IsUnicode(false).HasMaxLength(250);
            modelBuilder.Entity<Employee>().Property(e => e.Contact).IsRequired().IsUnicode(false).HasMaxLength(20);
            //1:m
            modelBuilder.Entity<Employee>().HasRequired(e => e.Department).WithMany(d => d.Employees).HasForeignKey(e => e.DepartmentId);


            modelBuilder.Entity<Department>().HasKey(e => e.DepartmentId);
            modelBuilder.Entity<Department>().Property(e => e.Name).IsRequired().IsUnicode(false).HasMaxLength(50);

            base.OnModelCreating(modelBuilder);
        }
    }
}
