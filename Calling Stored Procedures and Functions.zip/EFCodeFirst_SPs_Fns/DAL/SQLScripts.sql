﻿Create Procedure usp_getEmployee
@EmployeeId int
As
begin
	Select * from Employee where EmployeeId=@EmployeeId
end

GO
Create Function fn_getEmployee(@EmployeeId int)
returns table
return (Select * from Employee where EmployeeId=@EmployeeId)

