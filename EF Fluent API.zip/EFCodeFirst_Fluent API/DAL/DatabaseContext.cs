﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(): base("DefaultConnection")
        {

        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasKey(e => e.EmployeeId).ToTable("Employee");
            modelBuilder.Entity<Employee>().Property(e => e.Name).IsRequired().IsUnicode(false).HasMaxLength(50);
            modelBuilder.Entity<Employee>().Property(e => e.Address).IsUnicode(false).HasMaxLength(250);
            modelBuilder.Entity<Employee>().Property(e => e.Contact).IsRequired().IsUnicode(false).HasMaxLength(20);
            //1:m
            modelBuilder.Entity<Employee>().HasRequired(e => e.Department).WithMany(d => d.Employees).HasForeignKey(e => e.DepartmentId);


            modelBuilder.Entity<Department>().HasKey(e => e.DepartmentId);
            modelBuilder.Entity<Department>().Property(e => e.Name).IsRequired().IsUnicode(false).HasMaxLength(50);
            
            base.OnModelCreating(modelBuilder);
        }
    }
}
