﻿Create Procedure usp_getEmployee
@EmployeeId int
As
begin
	Select * from Employee where EmployeeId=@EmployeeId
end

GO
Create Function fn_getEmployee(@EmployeeId int)
returns table
return (Select * from Employee where EmployeeId=@EmployeeId)

GO
Create Procedure [dbo].[usp_getEmployeeCount]
@DepartmentId int,
@EmployeeCount int output
As
begin
	Select @EmployeeCount = COUNT(EmployeeId) from Employee where DepartmentId=@DepartmentId
end

GO

Create Procedure [dbo].[usp_getEmployeeDepartment]
@DepartmentId int
As
begin
	Select * from Employee where DepartmentId=@DepartmentId;
	Select * from Departments;
end
