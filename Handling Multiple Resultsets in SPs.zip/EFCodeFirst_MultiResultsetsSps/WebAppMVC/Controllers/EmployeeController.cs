﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppMVC.Controllers
{
    public class EmployeeController : Controller
    {
        DatabaseContext db = new DatabaseContext();
        public ActionResult Index()
        {
            //List<Employee> data = db.Employees.ToList();
            int DepartmentId = 1;

            var result = db.usp_getEmployeeDepartment(DepartmentId);
            return View(result.Employees);
        }

        public ActionResult Create()
        {
            ViewBag.DepartmentList = db.Departments.ToList();
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee model)
        {
            ModelState.Remove("EmployeeId");
            if (ModelState.IsValid)
            {
                db.Employees.Add(model);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DepartmentList = db.Departments.ToList();
            return View();
        }

        public ActionResult Edit(int id)
        {
            ViewBag.DepartmentList = db.Departments.ToList();
            //Employee model = db.Employees.Find(id);

            //Employee model = db.fn_getEmployee(id);
            Employee model = db.usp_getEmployee(id);

            int DeptId = 1;
            int Count = db.usp_getEmployeeCount(DeptId);
            return View("Create", model);
        }

        [HttpPost]
        public ActionResult Edit(Employee model)
        {
            if (ModelState.IsValid)
            {
                // db.Entry(model).State = System.Data.Entity.EntityState.Modified;

                Employee data = db.Employees.Find(model.EmployeeId);
                data.Name = model.Name;
                data.Address = model.Address;

                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DepartmentList = db.Departments.ToList();
            return View();
        }

        public ActionResult Delete(int id)
        {
            Employee model = db.Employees.Find(id);
            if(model!=null)
            {
                db.Employees.Remove(model);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}